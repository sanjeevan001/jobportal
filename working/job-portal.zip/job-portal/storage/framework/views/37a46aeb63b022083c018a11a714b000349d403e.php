

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($job->title); ?></h1>
    <p><?php echo e($job->description); ?></p>
    <small>Posted on <?php echo e($job->created_at); ?> by <?php echo e($job->company); ?></small>
    <hr>
    <a href="/applications/create/<?php echo e($job->id); ?>" class="btn btn-primary">Apply</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\New folder\New folder\job-portal\resources\views/jobs/show.blade.php ENDPATH**/ ?>