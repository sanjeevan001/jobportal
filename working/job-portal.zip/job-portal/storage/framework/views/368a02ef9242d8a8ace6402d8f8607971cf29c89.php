

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Apply for <?php echo e($job->title); ?></h1>
    <?php echo Form::open(['action' => ['App\Http\Controllers\ApplicationController@store', $job->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('name', 'Full Name')); ?>

            <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Full Name'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('email', 'Email')); ?>

            <?php echo e(Form::email('email', '', ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

        </div>
        <div class="form-group">

        <?php echo e(Form::text('phone', '', ['class' => 'form-control', 'placeholder' => 'Phone Number'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('resume', 'Resume')); ?>

            <?php echo e(Form::file('resume')); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cover_letter', 'Cover Letter')); ?>

            <?php echo e(Form::textarea('cover_letter', '', ['class' => 'form-control', 'placeholder' => 'Cover Letter'])); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\New folder\working\job-portal\resources\views/applications/create.blade.php ENDPATH**/ ?>