

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create Job</h1>
    <?php echo Form::open(['action' => 'App\Http\Controllers\JobController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('title', 'Title')); ?>

            <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('company', 'Company')); ?>

            <?php echo e(Form::text('company', '', ['class' => 'form-control', 'placeholder' => 'Company'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('description', 'Description')); ?>

            <?php echo e(Form::textarea('description', '', ['class' => 'form-control', 'placeholder' => 'Description'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('qualifications', 'Qualifications')); ?>

            <?php echo e(Form::textarea('qualifications', '', ['class' => 'form-control', 'placeholder' => 'Qualifications'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('location', 'Location')); ?>

            <?php echo e(Form::text('location', '', ['class' => 'form-control', 'placeholder' => 'Location'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('deadline', 'Application Deadline')); ?>

            <?php echo e(Form::date('deadline', '', ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::file('logo')); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\New folder\New folder\job-portal\resources\views/jobs/create.blade.php ENDPATH**/ ?>