

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Job Listings</h1>
    <?php if(count($jobs) > 0): ?>
        <ul class="list-group">
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <a href="/jobs/<?php echo e($job->id); ?>"><?php echo e($job->title); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <p>No jobs found</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\New folder\working\job-portal\resources\views/jobs/index.blade.php ENDPATH**/ ?>